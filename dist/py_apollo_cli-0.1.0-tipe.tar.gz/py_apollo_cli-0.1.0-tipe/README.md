# py_apollo_cli


## 入门使用:

* 见demo目录

## 功能点：
* apollo配置中心拉取配置
* 支持回调接口
* secret认证
* 支持灰度发布
* 支持本地文件缓存
* 默认开启热更新，参数配置可以不开启热更新
* 同时支持python2.x和python3.x，详情见./apollo/下的python_2x.py和python_3x.py文件


## 内部源打包和安装

> https://iwiki.woa.com/pages/viewpage.action?pageId=50796072

> https://iwiki.woa.com/pages/viewpage.action?pageId=4008129464#pypi-%E7%BB%84%E4%BB%B6%E5%8F%91%E5%B8%83

## Pack

```shell

# 检查Python组件
python setup.py check
 
# 以source方式打包，后缀名为tar.gz
python -m build --sdist
 
# 以wheel方式打包，后缀名为whl
python -m build --wheel

python setup.py sdist upload -r tencent
```

## Install

```shell
pip install -U py_apollo_cli --index-url=https://mirrors.tencent.com/repository/pypi/tencent_pypi/simple --trusted-host mirrors.cloud.tencent.com

pip install -U py_apollo_cli -i https://mirrors.cloud.tencent.com/pypi/simple/ --trusted-host mirrors.cloud.tencent.com

# 如果是在 在线编码jupyterlab 安装，请使用
%pip install -U py_apollo_cli -i https://mirrors.cloud.tencent.com/pypi/simple/ --trusted-host mirrors.cloud.tencent.com

```

```shell
pip config set global.index-url https://mirrors.tencent.com/repository/pypi/tencent_pypi/simple
```
