from py_apollo_cli import apollo

apollo.get_config()